public class Pair {
    // o clasa pereche utilizate pentru retinerea perechilor de lungime cuvant - numar aparitii
    private int a;
    private int b;

    public Pair(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }
}
